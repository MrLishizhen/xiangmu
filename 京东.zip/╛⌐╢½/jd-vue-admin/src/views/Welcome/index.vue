<template>
	<div>这是欢迎界面</div>
</template>

<script type="text/ecmascript-6">
        export default {};
</script>

<style scoped>

</style>