//导入这两个vue组件
import Login from './Login.vue';
import Home from './Home.vue';

//导出这两个vue组件
export default{Login,Home};
