<template>
	<!--占位从其他位置过来的都是在这里显示-->
	<router-view></router-view>
</template>

<script type="text/ecmascript-6"></script>

<style scoped></style>