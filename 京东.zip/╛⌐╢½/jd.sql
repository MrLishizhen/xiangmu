/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 80011
Source Host           : 127.0.0.1:3306
Source Database       : jd

Target Server Type    : MYSQL
Target Server Version : 80011
File Encoding         : 65001

Date: 2020-01-05 10:45:22
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for dt_address
-- ----------------------------
DROP TABLE IF EXISTS `dt_address`;
CREATE TABLE `dt_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(16) NOT NULL,
  `receiveName` varchar(16) NOT NULL,
  `receivePhone` varchar(11) NOT NULL,
  `receiveRegion` varchar(50) NOT NULL,
  `receiveDetail` varchar(50) NOT NULL,
  `isDefault` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_address_name_user_name` (`name`),
  CONSTRAINT `fk_address_name_user_name` FOREIGN KEY (`name`) REFERENCES `dt_user` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dt_address
-- ----------------------------
INSERT INTO `dt_address` VALUES ('1', 'user1', '张三', '17560640208', '天津市-市辖区-和平区-小白楼街道', '北柳', '0');
INSERT INTO `dt_address` VALUES ('2', 'user1', '二狗子', '15854521155', '北京市-市辖区-东城区-东华门街道', '我在你身边', '0');
INSERT INTO `dt_address` VALUES ('11', 'user1', '李世镇', '15865876025', '山西省-大同市-矿区-新平旺街道', '摄入和我', '1');

-- ----------------------------
-- Table structure for dt_admin
-- ----------------------------
DROP TABLE IF EXISTS `dt_admin`;
CREATE TABLE `dt_admin` (
  `name` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `identity` int(11) NOT NULL DEFAULT '0' COMMENT '身份',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dt_admin
-- ----------------------------
INSERT INTO `dt_admin` VALUES ('秋雨不良人', '123456', '0');

-- ----------------------------
-- Table structure for dt_cart
-- ----------------------------
DROP TABLE IF EXISTS `dt_cart`;
CREATE TABLE `dt_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(16) NOT NULL,
  `pid` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `addTime` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cart_name_user_name` (`name`),
  KEY `fk_cart_pid_product_id` (`pid`),
  CONSTRAINT `fk_cart_name_user_name` FOREIGN KEY (`name`) REFERENCES `dt_user` (`name`),
  CONSTRAINT `fk_cart_pid_product_id` FOREIGN KEY (`pid`) REFERENCES `dt_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dt_cart
-- ----------------------------
INSERT INTO `dt_cart` VALUES ('7', 'user2', '5', '4', '0');
INSERT INTO `dt_cart` VALUES ('66', 'user1', '14', '2', '2020-01-02 10:46:55.805');

-- ----------------------------
-- Table structure for dt_category
-- ----------------------------
DROP TABLE IF EXISTS `dt_category`;
CREATE TABLE `dt_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `fid` int(11) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=409 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dt_category
-- ----------------------------
INSERT INTO `dt_category` VALUES ('1', '热门推荐 ', '0', null);
INSERT INTO `dt_category` VALUES ('2', '手机数码', '0', null);
INSERT INTO `dt_category` VALUES ('3', '家用电器', '0', null);
INSERT INTO `dt_category` VALUES ('4', '电脑办公', '0', null);
INSERT INTO `dt_category` VALUES ('5', '美妆护肤', '0', null);
INSERT INTO `dt_category` VALUES ('6', '个护清洁', '0', null);
INSERT INTO `dt_category` VALUES ('7', '汽车生活', '0', null);
INSERT INTO `dt_category` VALUES ('8', '京东超市', '0', null);
INSERT INTO `dt_category` VALUES ('9', '男装', '0', null);
INSERT INTO `dt_category` VALUES ('10', '男鞋', '0', null);
INSERT INTO `dt_category` VALUES ('11', '女装', '0', null);
INSERT INTO `dt_category` VALUES ('12', '女鞋', '0', null);
INSERT INTO `dt_category` VALUES ('13', '母婴童装', '0', null);
INSERT INTO `dt_category` VALUES ('14', '图书音像', '0', '');
INSERT INTO `dt_category` VALUES ('15', '运动户外', '0', null);
INSERT INTO `dt_category` VALUES ('16', '内衣配饰', '0', null);
INSERT INTO `dt_category` VALUES ('17', '热门分类', '1', null);
INSERT INTO `dt_category` VALUES ('18', '家电热搜', '1', null);
INSERT INTO `dt_category` VALUES ('19', '热门品牌', '2', null);
INSERT INTO `dt_category` VALUES ('20', '手机通讯', '2', null);
INSERT INTO `dt_category` VALUES ('21', '厨房小电', '3', null);
INSERT INTO `dt_category` VALUES ('22', '个护健康', '3', null);
INSERT INTO `dt_category` VALUES ('23', '热卖分类', '4', null);
INSERT INTO `dt_category` VALUES ('24', '电脑整机', '4', null);
INSERT INTO `dt_category` VALUES ('25', '当季主推', '5', null);
INSERT INTO `dt_category` VALUES ('26', '拔草推荐', '5', null);
INSERT INTO `dt_category` VALUES ('27', '畅销推荐', '6', null);
INSERT INTO `dt_category` VALUES ('28', '明星品牌', '6', null);
INSERT INTO `dt_category` VALUES ('29', '热卖推荐', '7', null);
INSERT INTO `dt_category` VALUES ('30', '全部车型', '7', null);
INSERT INTO `dt_category` VALUES ('31', '个护清洁', '8', null);
INSERT INTO `dt_category` VALUES ('32', '休闲零食', '8', null);
INSERT INTO `dt_category` VALUES ('33', '热卖选购', '9', null);
INSERT INTO `dt_category` VALUES ('34', '男士内搭', '9', null);
INSERT INTO `dt_category` VALUES ('35', '热卖分类', '10', null);
INSERT INTO `dt_category` VALUES ('36', '流行男鞋', '10', null);
INSERT INTO `dt_category` VALUES ('37', '热卖选购', '11', null);
INSERT INTO `dt_category` VALUES ('38', '上装', '11', null);
INSERT INTO `dt_category` VALUES ('39', '热卖分类', '12', null);
INSERT INTO `dt_category` VALUES ('40', '时尚女鞋', '12', null);
INSERT INTO `dt_category` VALUES ('41', '奶粉', '13', null);
INSERT INTO `dt_category` VALUES ('42', '营养辅食', '13', null);
INSERT INTO `dt_category` VALUES ('43', '热门推荐', '14', null);
INSERT INTO `dt_category` VALUES ('44', '文学', '14', null);
INSERT INTO `dt_category` VALUES ('45', '运动热门购', '15', null);
INSERT INTO `dt_category` VALUES ('46', '健身训练', '15', null);
INSERT INTO `dt_category` VALUES ('47', '热卖品类', '16', null);
INSERT INTO `dt_category` VALUES ('48', '内裤', '16', null);
INSERT INTO `dt_category` VALUES ('49', '手机', '17', '/images/category/1-1.png');
INSERT INTO `dt_category` VALUES ('50', '耳机', '17', '/images/category/1-2.png');
INSERT INTO `dt_category` VALUES ('51', '华为', '17', '/images/category/1-3.png');
INSERT INTO `dt_category` VALUES ('52', '电饭煲', '17', '/images/category/1-4.png');
INSERT INTO `dt_category` VALUES ('53', '电磁炉', '17', '/images/category/1-5.png');
INSERT INTO `dt_category` VALUES ('54', '路由器', '17', '/images/category/1-6.png');
INSERT INTO `dt_category` VALUES ('55', '避孕套', '17', '/images/category/1-7.png');
INSERT INTO `dt_category` VALUES ('56', '口红', '17', '/images/category/1-8.png');
INSERT INTO `dt_category` VALUES ('57', '吹风机', '17', '/images/category/1-9.png');
INSERT INTO `dt_category` VALUES ('58', '三只松鼠', '17', '/images/category/1-10.png');
INSERT INTO `dt_category` VALUES ('59', '洗衣液', '17', '/images/category/1-11.png');
INSERT INTO `dt_category` VALUES ('60', '保温杯', '17', '/images/category/1-12.png');
INSERT INTO `dt_category` VALUES ('61', '微波炉', '17', '/images/category/1-13.png');
INSERT INTO `dt_category` VALUES ('62', '洗发水', '17', '/images/category/1-14.png');
INSERT INTO `dt_category` VALUES ('63', '卫生巾', '17', '/images/category/1-15.png');
INSERT INTO `dt_category` VALUES ('64', '冰箱', '18', '/images/category/1-16.png');
INSERT INTO `dt_category` VALUES ('65', '洗衣机', '18', '/images/category/1-17.png');
INSERT INTO `dt_category` VALUES ('66', '电视', '18', '/images/category/1-18.png');
INSERT INTO `dt_category` VALUES ('67', '小米', '19', '/images/category/2-1.png');
INSERT INTO `dt_category` VALUES ('68', '华为', '19', '/images/category/2-2.jpg');
INSERT INTO `dt_category` VALUES ('69', '荣耀', '19', '/images/category/2-3.jpg');
INSERT INTO `dt_category` VALUES ('70', 'IPone', '19', '/images/category/2-4.jpg');
INSERT INTO `dt_category` VALUES ('71', 'vivo', '19', '/images/category/2-5.png');
INSERT INTO `dt_category` VALUES ('72', 'OPPO', '19', '/images/category/2-6.png');
INSERT INTO `dt_category` VALUES ('73', '魅族', '19', '/images/category/2-7.jpg');
INSERT INTO `dt_category` VALUES ('74', '三星', '19', '/images/category/2-8.png');
INSERT INTO `dt_category` VALUES ('75', '一加', '19', '/images/category/2-9.jpg');
INSERT INTO `dt_category` VALUES ('76', '360手机', '19', '/images/category/2-10.jpg');
INSERT INTO `dt_category` VALUES ('77', '锤子手机', '19', '/images/category/2-11.jpg');
INSERT INTO `dt_category` VALUES ('78', '努比亚', '19', '/images/category/2-12.jpg');
INSERT INTO `dt_category` VALUES ('79', '老人机', '20', '/images/category/2-13.jpg');
INSERT INTO `dt_category` VALUES ('80', '手机', '20', '/images/category/2-14.jpg');
INSERT INTO `dt_category` VALUES ('81', '全面屏手机', '20', '/images/category/2-15.jpg');
INSERT INTO `dt_category` VALUES ('82', '游戏手机', '20', '/images/category/2-16.jpg');
INSERT INTO `dt_category` VALUES ('83', '拍照手机', '20', '/images/category/2-17.jpg');
INSERT INTO `dt_category` VALUES ('84', '对讲机', '20', '/images/category/2-18.jpg');
INSERT INTO `dt_category` VALUES ('85', '京东回收', '20', '/images/category/2-19.jpg');
INSERT INTO `dt_category` VALUES ('86', '女性手机', '20', '/images/category/2-20.jpg');
INSERT INTO `dt_category` VALUES ('87', '京东维修', '20', '/images/category/2-21.jpg');
INSERT INTO `dt_category` VALUES ('88', '电水壶/热水瓶', '21', '/images/category/3-1.jpg');
INSERT INTO `dt_category` VALUES ('89', '电压力锅', '21', '/images/category/3-2.jpg');
INSERT INTO `dt_category` VALUES ('90', '电饭煲', '21', '/images/category/3-3.jpg');
INSERT INTO `dt_category` VALUES ('91', '电磁炉', '21', '/images/category/3-4.jpg');
INSERT INTO `dt_category` VALUES ('92', '微波炉', '21', '/images/category/3-5.jpg');
INSERT INTO `dt_category` VALUES ('93', '电饼档', '21', '/images/category/3-6.jpg');
INSERT INTO `dt_category` VALUES ('94', '豆浆机', '21', '/images/category/3-7.jpg');
INSERT INTO `dt_category` VALUES ('95', '多用途锅', '21', '/images/category/3-8.jpg');
INSERT INTO `dt_category` VALUES ('96', '料理机', '21', '/images/category/3-9.jpg');
INSERT INTO `dt_category` VALUES ('97', '榨汁机/原汁机', '21', '/images/category/3-10.jpg');
INSERT INTO `dt_category` VALUES ('98', '电烤箱', '21', '/images/category/3-11.jpg');
INSERT INTO `dt_category` VALUES ('99', '养生壶/煎药壶', '21', '/images/category/3-12.jpg');
INSERT INTO `dt_category` VALUES ('100', '电炖锅', '21', '/images/category/3-13.jpg');
INSERT INTO `dt_category` VALUES ('101', '电烧烤炉', '21', '/images/category/3-14.jpg');
INSERT INTO `dt_category` VALUES ('102', '面包机', '21', '/images/category/3-15.jpg');
INSERT INTO `dt_category` VALUES ('103', '面条机', '21', '/images/category/3-16.jpg');
INSERT INTO `dt_category` VALUES ('104', '煮蛋机', '21', '/images/category/3-17.jpg');
INSERT INTO `dt_category` VALUES ('105', '电热饭盒', '21', '/images/category/3-18.jpg');
INSERT INTO `dt_category` VALUES ('106', '面条机', '21', '/images/category/3-19.jpg');
INSERT INTO `dt_category` VALUES ('107', '酸奶机', '21', '/images/category/3-20.jpg');
INSERT INTO `dt_category` VALUES ('108', '空气炸锅', '21', '/images/category/3-21.jpg');
INSERT INTO `dt_category` VALUES ('109', '蔬果解毒机', '21', '/images/category/3-22.jpg');
INSERT INTO `dt_category` VALUES ('110', '电吹风', '22', '/images/category/3-23.png');
INSERT INTO `dt_category` VALUES ('111', '剃须刀', '22', '/images/category/3-24.jpg');
INSERT INTO `dt_category` VALUES ('112', '理发器', '22', '/images/category/3-25.jpg');
INSERT INTO `dt_category` VALUES ('113', '足浴盆', '22', '/images/category/3-26.jpg');
INSERT INTO `dt_category` VALUES ('114', '剃/脱毛器', '22', '/images/category/3-27.jpg');
INSERT INTO `dt_category` VALUES ('115', '按摩器', '22', '/images/category/3-28.jpg');
INSERT INTO `dt_category` VALUES ('116', '卷/直发棒', '22', '/images/category/3-29.jpg');
INSERT INTO `dt_category` VALUES ('117', '按摩椅', '22', '/images/category/3-30.jpg');
INSERT INTO `dt_category` VALUES ('118', '口腔护理', '22', '/images/category/3-31.jpg');
INSERT INTO `dt_category` VALUES ('119', '电子秤', '22', '/images/category/3-32.jpg');
INSERT INTO `dt_category` VALUES ('120', '美容器', '22', '/images/category/3-33.jpg');
INSERT INTO `dt_category` VALUES ('121', '其他健康电器', '22', '/images/category/3-34.jpg');
INSERT INTO `dt_category` VALUES ('122', '轻薄本', '23', '/images/category/4-1.png');
INSERT INTO `dt_category` VALUES ('123', '游戏本', '23', '/images/category/4-2.png');
INSERT INTO `dt_category` VALUES ('124', '机械键盘', '23', '/images/category/4-3.jpg');
INSERT INTO `dt_category` VALUES ('125', '组装电器', '23', '/images/category/4-4.jpg');
INSERT INTO `dt_category` VALUES ('126', '移动硬盘', '23', '/images/category/4-5.jpg');
INSERT INTO `dt_category` VALUES ('127', '显卡', '23', '/images/category/4-6.jpg');
INSERT INTO `dt_category` VALUES ('128', '游戏台式机', '23', '/images/category/4-7.jpg');
INSERT INTO `dt_category` VALUES ('129', '家用打印机', '23', '/images/category/4-8.jpg');
INSERT INTO `dt_category` VALUES ('130', '吃鸡装备', '23', '/images/category/4-9.jpg');
INSERT INTO `dt_category` VALUES ('131', '曲屏显示器', '23', '/images/category/4-10.jpg');
INSERT INTO `dt_category` VALUES ('132', '投影机', '23', '/images/category/4-11.jpg');
INSERT INTO `dt_category` VALUES ('133', '日本文具', '23', '/images/category/4-12.jpg');
INSERT INTO `dt_category` VALUES ('134', '笔记本', '24', '/images/category/4-13.jpg');
INSERT INTO `dt_category` VALUES ('135', '平板电脑', '24', '/images/category/4-14.jpg');
INSERT INTO `dt_category` VALUES ('136', '一体机', '24', '/images/category/4-15.jpg');
INSERT INTO `dt_category` VALUES ('137', '台式机', '24', '/images/category/4-16.jpg');
INSERT INTO `dt_category` VALUES ('138', '笔记本配件', '24', '/images/category/4-17.jpg');
INSERT INTO `dt_category` VALUES ('139', '游戏台式机', '24', '/images/category/4-18.jpg');
INSERT INTO `dt_category` VALUES ('140', '商用台式机', '24', '/images/category/4-19.jpg');
INSERT INTO `dt_category` VALUES ('141', '游戏本', '24', '/images/category/4-20.jpg');
INSERT INTO `dt_category` VALUES ('142', '平板电脑配件', '24', '/images/category/4-21.jpg');
INSERT INTO `dt_category` VALUES ('143', '轻薄本', '24', '/images/category/4-22.jpg');
INSERT INTO `dt_category` VALUES ('144', '二合一平板', '24', '/images/category/4-23.jpg');
INSERT INTO `dt_category` VALUES ('145', '服务站/工作站', '24', '/images/category/4-24.jpg');
INSERT INTO `dt_category` VALUES ('146', '美白 ', '25', '/images/category/5-1.jpg');
INSERT INTO `dt_category` VALUES ('147', '防晒', '25', '/images/category/5-2.jpg');
INSERT INTO `dt_category` VALUES ('148', '控油', '25', '/images/category/5-3.jpg');
INSERT INTO `dt_category` VALUES ('149', '明星同款面膜', '26', '/images/category/5-4.jpg');
INSERT INTO `dt_category` VALUES ('150', '显白口红', '26', '/images/category/5-5.jpg');
INSERT INTO `dt_category` VALUES ('151', '小美盒', '26', '/images/category/5-6.jpg');
INSERT INTO `dt_category` VALUES ('152', '个护馆', '27', '/images/category/6-1.jpg');
INSERT INTO `dt_category` VALUES ('153', '清洁馆', '27', '/images/category/6-2.jpg');
INSERT INTO `dt_category` VALUES ('154', '进口清洁', '27', '/images/category/6-3.jpg');
INSERT INTO `dt_category` VALUES ('155', '卫生棉条', '27', '/images/category/6-4.jpg');
INSERT INTO `dt_category` VALUES ('156', '湿厕纸', '27', '/images/category/6-5.jpg');
INSERT INTO `dt_category` VALUES ('157', '走珠/止汗露', '27', '/images/category/6-6.jpg');
INSERT INTO `dt_category` VALUES ('158', '花露水', '27', '/images/category/6-7.jpg');
INSERT INTO `dt_category` VALUES ('159', '驱蚊用品', '27', '/images/category/6-8.jpg');
INSERT INTO `dt_category` VALUES ('160', '本色纸', '27', '/images/category/6-9.jpg');
INSERT INTO `dt_category` VALUES ('161', '免洗洗手液', '27', '/images/category/6-10.jpg');
INSERT INTO `dt_category` VALUES ('162', '得宝', '28', '/images/category/6-11.jpg');
INSERT INTO `dt_category` VALUES ('163', '施华蔻专业', '28', '/images/category/6-12.jpg');
INSERT INTO `dt_category` VALUES ('164', '舒洁', '28', '/images/category/6-13.jpg');
INSERT INTO `dt_category` VALUES ('165', '馥绿德雅', '28', '/images/category/6-14.jpg');
INSERT INTO `dt_category` VALUES ('166', '3M', '28', '/images/category/6-15.jpg');
INSERT INTO `dt_category` VALUES ('167', '吕', '28', '/images/category/6-16.jpg');
INSERT INTO `dt_category` VALUES ('168', '当妮', '28', '/images/category/6-17.jpg');
INSERT INTO `dt_category` VALUES ('169', 'LG', '28', '/images/category/6-18.jpg');
INSERT INTO `dt_category` VALUES ('170', '橘子工坊', '28', '/images/category/6-19.jpg');
INSERT INTO `dt_category` VALUES ('171', '花王', '28', '/images/category/6-20.jpg');
INSERT INTO `dt_category` VALUES ('172', '汉高', '28', '/images/category/6-21.jpg');
INSERT INTO `dt_category` VALUES ('173', '玛尔斯', '28', '/images/category/6-22.jpg');
INSERT INTO `dt_category` VALUES ('174', '机油', '29', '/images/category/7-1.jpg');
INSERT INTO `dt_category` VALUES ('175', '汽车坐垫', '29', '/images/category/7-2.jpg');
INSERT INTO `dt_category` VALUES ('176', '洗车水枪', '29', '/images/category/7-3.jpg');
INSERT INTO `dt_category` VALUES ('177', '行车记录仪', '29', '/images/category/7-4.jpg');
INSERT INTO `dt_category` VALUES ('178', '轮胎', '29', '/images/category/7-5.jpg');
INSERT INTO `dt_category` VALUES ('179', '应急救援', '29', '/images/category/7-6.png');
INSERT INTO `dt_category` VALUES ('180', '全部车型', '30', '/images/category/7-7.jpg');
INSERT INTO `dt_category` VALUES ('181', '大众', '30', '/images/category/7-8.jpg');
INSERT INTO `dt_category` VALUES ('182', '日产', '30', '/images/category/7-9.jpg');
INSERT INTO `dt_category` VALUES ('183', '丰田', '30', '/images/category/7-10.jpg');
INSERT INTO `dt_category` VALUES ('184', '奥迪', '30', '/images/category/7-11.jpg');
INSERT INTO `dt_category` VALUES ('185', '别克', '30', '/images/category/7-12.jpg');
INSERT INTO `dt_category` VALUES ('186', '宝骏', '30', '/images/category/7-13.jpg');
INSERT INTO `dt_category` VALUES ('187', '本田', '30', '/images/category/7-14.jpg');
INSERT INTO `dt_category` VALUES ('188', '斯柯达', '30', '/images/category/7-15.jpg');
INSERT INTO `dt_category` VALUES ('189', '凯迪拉克', '30', '/images/category/7-16.jpg');
INSERT INTO `dt_category` VALUES ('190', '名爵', '30', '/images/category/7-17.jpg');
INSERT INTO `dt_category` VALUES ('191', '二手车', '30', '/images/category/7-18.jpg');
INSERT INTO `dt_category` VALUES ('192', '奥迪Q5L', '30', '/images/category/7-19.jpg');
INSERT INTO `dt_category` VALUES ('193', '轩逸', '30', '/images/category/7-20.jpg');
INSERT INTO `dt_category` VALUES ('194', '迈腾', '30', '/images/category/7-21.jpg');
INSERT INTO `dt_category` VALUES ('195', '纸品湿巾', '31', '/images/category/8-1.jpg');
INSERT INTO `dt_category` VALUES ('196', '衣物清洁', '31', '/images/category/8-2.jpg');
INSERT INTO `dt_category` VALUES ('197', '洗发护发', '31', '/images/category/8-3.jpg');
INSERT INTO `dt_category` VALUES ('198', '家庭清洁', '31', '/images/category/8-4.jpg');
INSERT INTO `dt_category` VALUES ('199', '口腔护理', '31', '/images/category/8-5.jpg');
INSERT INTO `dt_category` VALUES ('200', '一次性用品', '31', '/images/category/8-6.jpg');
INSERT INTO `dt_category` VALUES ('201', '清洁工具', '31', '/images/category/8-7.jpg');
INSERT INTO `dt_category` VALUES ('202', '电动牙刷', '31', '/images/category/8-8.jpg');
INSERT INTO `dt_category` VALUES ('203', '女性护理', '31', '/images/category/8-9.jpg');
INSERT INTO `dt_category` VALUES ('204', '驱虫用品', '31', '/images/category/8-10.jpg');
INSERT INTO `dt_category` VALUES ('205', '皮具护理', '31', '/images/category/8-11.jpg');
INSERT INTO `dt_category` VALUES ('206', '休闲零食', '32', '/images/category/8-12.jpg');
INSERT INTO `dt_category` VALUES ('207', '坚果炒货', '32', '/images/category/8-13.png');
INSERT INTO `dt_category` VALUES ('208', '糖巧', '32', '/images/category/8-14.png');
INSERT INTO `dt_category` VALUES ('209', '饼干蛋糕', '32', '/images/category/8-15.jpg');
INSERT INTO `dt_category` VALUES ('210', '肉干肉铺', '32', '/images/category/8-16.jpg');
INSERT INTO `dt_category` VALUES ('211', '蜜饯果干', '32', '/images/category/8-17.jpg');
INSERT INTO `dt_category` VALUES ('212', '无糖食品', '32', '/images/category/8-18.jpg');
INSERT INTO `dt_category` VALUES ('213', '夹克', '33', '/images/category/9-1.jpg');
INSERT INTO `dt_category` VALUES ('214', 'T恤', '33', '/images/category/9-2.jpg');
INSERT INTO `dt_category` VALUES ('215', '针织衫', '33', '/images/category/9-3.jpg');
INSERT INTO `dt_category` VALUES ('216', '衬衫', '33', '/images/category/9-4.jpg');
INSERT INTO `dt_category` VALUES ('217', '卫衣', '33', '/images/category/9-5.jpg');
INSERT INTO `dt_category` VALUES ('218', '风衣', '33', '/images/category/9-6.jpg');
INSERT INTO `dt_category` VALUES ('219', '牛仔裤', '33', '/images/category/9-7.jpg');
INSERT INTO `dt_category` VALUES ('220', '休闲裤', '33', '/images/category/9-8.jpg');
INSERT INTO `dt_category` VALUES ('221', '自营男装', '33', '/images/category/9-9.jpg');
INSERT INTO `dt_category` VALUES ('222', '新品T恤', '34', '/images/category/9-10.png');
INSERT INTO `dt_category` VALUES ('223', '短袖T恤', '34', '/images/category/9-11.jpg');
INSERT INTO `dt_category` VALUES ('224', '新品衬衫', '34', '/images/category/9-12.jpg');
INSERT INTO `dt_category` VALUES ('225', '短袖衬衫', '34', '/images/category/9-13.jpg');
INSERT INTO `dt_category` VALUES ('226', '新品卫衣', '34', '/images/category/9-14.jpg');
INSERT INTO `dt_category` VALUES ('227', '连帽卫衣', '34', '/images/category/9-15.jpg');
INSERT INTO `dt_category` VALUES ('228', '潮牌卫衣', '34', '/images/category/9-16.jpg');
INSERT INTO `dt_category` VALUES ('229', '长袖T恤', '34', '/images/category/9-17.jpg');
INSERT INTO `dt_category` VALUES ('230', '长袖衬衫', '34', '/images/category/9-18.jpg');
INSERT INTO `dt_category` VALUES ('231', '免烫衬衫', '34', '/images/category/9-19.jpg');
INSERT INTO `dt_category` VALUES ('232', '针织衫', '34', '/images/category/9-20.jpg');
INSERT INTO `dt_category` VALUES ('233', 'POLO衫', '34', '/images/category/9-21.jpg');
INSERT INTO `dt_category` VALUES ('234', '休闲鞋', '35', '/images/category/10-1.jpg');
INSERT INTO `dt_category` VALUES ('235', '皮鞋', '35', '/images/category/10-2.jpg');
INSERT INTO `dt_category` VALUES ('236', '男靴', '35', '/images/category/10-3.jpg');
INSERT INTO `dt_category` VALUES ('237', '帆布鞋', '35', '/images/category/10-4.jpg');
INSERT INTO `dt_category` VALUES ('238', '板鞋', '35', '/images/category/10-5.jpg');
INSERT INTO `dt_category` VALUES ('239', '自营鞋靴', '35', '/images/category/10-6.jpg');
INSERT INTO `dt_category` VALUES ('240', '新品推荐', '35', '/images/category/10-7.jpg');
INSERT INTO `dt_category` VALUES ('241', '休闲鞋', '36', '/images/category/10-8.jpg');
INSERT INTO `dt_category` VALUES ('242', '休闲户外鞋', '36', '/images/category/10-9.jpg');
INSERT INTO `dt_category` VALUES ('243', '凉鞋', '36', '/images/category/10-10.jpg');
INSERT INTO `dt_category` VALUES ('244', '功能鞋', '36', '/images/category/10-11.jpg');
INSERT INTO `dt_category` VALUES ('245', '豆豆鞋', '36', '/images/category/10-12.jpg');
INSERT INTO `dt_category` VALUES ('246', '商务休闲鞋', '36', '/images/category/10-13.jpg');
INSERT INTO `dt_category` VALUES ('247', '传统布鞋', '36', '/images/category/10-14.jpg');
INSERT INTO `dt_category` VALUES ('248', '板鞋', '36', '/images/category/10-15.jpg');
INSERT INTO `dt_category` VALUES ('249', '正装鞋', '36', '/images/category/10-16.jpg');
INSERT INTO `dt_category` VALUES ('250', '增高鞋', '36', '/images/category/10-17.jpg');
INSERT INTO `dt_category` VALUES ('251', '拖鞋/人字拖', '36', '/images/category/10-18.jpg');
INSERT INTO `dt_category` VALUES ('252', '男靴', '36', '/images/category/10-19.jpg');
INSERT INTO `dt_category` VALUES ('253', '乐福鞋', '36', '/images/category/10-20.jpg');
INSERT INTO `dt_category` VALUES ('254', '帆布鞋', '36', '/images/category/10-21.jpg');
INSERT INTO `dt_category` VALUES ('255', '工装鞋', '36', '/images/category/10-22.jpg');
INSERT INTO `dt_category` VALUES ('256', '鞋配件', '36', '/images/category/10-23.jpg');
INSERT INTO `dt_category` VALUES ('257', '雨鞋', '36', '/images/category/10-24.jpg');
INSERT INTO `dt_category` VALUES ('258', '定制鞋', '36', '/images/category/10-25.jpg');
INSERT INTO `dt_category` VALUES ('259', '早春新品', '37', '/images/category/11-1.jpg');
INSERT INTO `dt_category` VALUES ('260', '连衣裙', '37', '/images/category/11-2.jpg');
INSERT INTO `dt_category` VALUES ('261', '衬衫', '37', '/images/category/11-3.jpg');
INSERT INTO `dt_category` VALUES ('262', 'T恤', '37', '/images/category/11-4.jpg');
INSERT INTO `dt_category` VALUES ('263', '牛仔裤', '37', '/images/category/11-5.jpg');
INSERT INTO `dt_category` VALUES ('264', '卫衣', '37', '/images/category/11-6.jpg');
INSERT INTO `dt_category` VALUES ('265', '针织衫', '37', '/images/category/11-7.jpg');
INSERT INTO `dt_category` VALUES ('266', '牛仔外套', '37', '/images/category/11-8.jpg');
INSERT INTO `dt_category` VALUES ('267', '自营女装', '37', '/images/category/11-9.jpg');
INSERT INTO `dt_category` VALUES ('268', '打底衫', '38', '/images/category/11-10.jpg');
INSERT INTO `dt_category` VALUES ('269', '短外套', '38', '/images/category/11-11.jpg');
INSERT INTO `dt_category` VALUES ('270', '百搭衬衫', '38', '/images/category/11-12.jpg');
INSERT INTO `dt_category` VALUES ('271', '风衣', '38', '/images/category/11-13.jpg');
INSERT INTO `dt_category` VALUES ('272', '长袖T恤', '38', '/images/category/11-14.jpg');
INSERT INTO `dt_category` VALUES ('273', '卫衣', '38', '/images/category/11-15.jpg');
INSERT INTO `dt_category` VALUES ('274', '小西装', '38', '/images/category/11-16.jpg');
INSERT INTO `dt_category` VALUES ('275', '宽松卫衣', '38', '/images/category/11-17.jpg');
INSERT INTO `dt_category` VALUES ('276', '雪纺织', '38', '/images/category/11-18.jpg');
INSERT INTO `dt_category` VALUES ('277', '长袖衬衫', '38', '/images/category/11-19.jpg');
INSERT INTO `dt_category` VALUES ('278', '字母T恤', '38', '/images/category/11-20.jpg');
INSERT INTO `dt_category` VALUES ('279', '棒球衫', '38', '/images/category/11-21.jpg');
INSERT INTO `dt_category` VALUES ('280', '白衬衫', '38', '/images/category/11-22.jpg');
INSERT INTO `dt_category` VALUES ('281', '针织衫', '38', '/images/category/11-23.jpg');
INSERT INTO `dt_category` VALUES ('282', '连帽卫衣', '38', '/images/category/11-24.jpg');
INSERT INTO `dt_category` VALUES ('283', '半高领针织', '38', '/images/category/11-25.jpg');
INSERT INTO `dt_category` VALUES ('284', '抢尖货', '39', '/images/category/12-1.jpg');
INSERT INTO `dt_category` VALUES ('285', '商场同款', '39', '/images/category/12-2.jpg');
INSERT INTO `dt_category` VALUES ('286', '原创设计', '39', '/images/category/12-3.jpg');
INSERT INTO `dt_category` VALUES ('287', '休闲鞋', '40', '/images/category/12-4.jpg');
INSERT INTO `dt_category` VALUES ('288', '中跟单鞋', '40', '/images/category/12-5.jpg');
INSERT INTO `dt_category` VALUES ('289', '大码女鞋', '40', '/images/category/12-6.jpg');
INSERT INTO `dt_category` VALUES ('290', '深口单鞋', '40', '/images/category/12-7.jpg');
INSERT INTO `dt_category` VALUES ('291', '粗跟单鞋', '40', '/images/category/12-8.jpg');
INSERT INTO `dt_category` VALUES ('292', '妈妈鞋', '40', '/images/category/12-9.jpg');
INSERT INTO `dt_category` VALUES ('293', '婚鞋', '40', '/images/category/12-10.jpg');
INSERT INTO `dt_category` VALUES ('294', '通勤OL', '40', '/images/category/12-11.jpg');
INSERT INTO `dt_category` VALUES ('295', '凉鞋', '40', '/images/category/12-12.jpg');
INSERT INTO `dt_category` VALUES ('296', '高跟单鞋', '40', '/images/category/12-13.jpg');
INSERT INTO `dt_category` VALUES ('297', '尖头单鞋', '40', '/images/category/12-14.jpg');
INSERT INTO `dt_category` VALUES ('298', '单鞋', '40', '/images/category/12-15.jpg');
INSERT INTO `dt_category` VALUES ('299', '平底单鞋', '40', '/images/category/12-16.jpg');
INSERT INTO `dt_category` VALUES ('300', '帆布鞋', '40', '/images/category/12-17.jpg');
INSERT INTO `dt_category` VALUES ('301', '小白鞋', '40', '/images/category/12-18.jpg');
INSERT INTO `dt_category` VALUES ('302', '玛丽珍', '40', '/images/category/12-19.jpg');
INSERT INTO `dt_category` VALUES ('303', '豆豆鞋', '40', '/images/category/12-20.jpg');
INSERT INTO `dt_category` VALUES ('304', '短靴', '40', '/images/category/12-21.jpg');
INSERT INTO `dt_category` VALUES ('305', '布鞋/绣花鞋', '40', '/images/category/12-22.jpg');
INSERT INTO `dt_category` VALUES ('306', '拖鞋/人字拖', '40', '/images/category/12-23.jpg');
INSERT INTO `dt_category` VALUES ('307', '内增高', '40', '/images/category/12-24.jpg');
INSERT INTO `dt_category` VALUES ('308', '雨鞋', '40', '/images/category/12-25.jpg');
INSERT INTO `dt_category` VALUES ('309', '鞋配件', '40', '/images/category/12-26.jpg');
INSERT INTO `dt_category` VALUES ('310', '袜靴', '40', '/images/category/12-27.jpg');
INSERT INTO `dt_category` VALUES ('311', '1段', '41', '/images/category/13-1.jpg');
INSERT INTO `dt_category` VALUES ('312', '2段', '41', '/images/category/13-2.jpg');
INSERT INTO `dt_category` VALUES ('313', '3段', '41', '/images/category/13-3.jpg');
INSERT INTO `dt_category` VALUES ('314', '4段', '41', '/images/category/13-4.jpg');
INSERT INTO `dt_category` VALUES ('315', '孕妈奶粉', '41', '/images/category/13-5.jpg');
INSERT INTO `dt_category` VALUES ('316', '特殊配方奶粉', '41', '/images/category/13-6.jpg');
INSERT INTO `dt_category` VALUES ('317', '有机奶粉', '41', '/images/category/13-7.jpg');
INSERT INTO `dt_category` VALUES ('318', '益生菌/初乳', '42', '/images/category/13-8.jpg');
INSERT INTO `dt_category` VALUES ('319', '果泥/果汁', '42', '/images/category/13-9.jpg');
INSERT INTO `dt_category` VALUES ('320', '米粉/彩粉', '42', '/images/category/13-10.jpg');
INSERT INTO `dt_category` VALUES ('321', 'DHA', '42', '/images/category/13-11.jpg');
INSERT INTO `dt_category` VALUES ('322', '宝宝零食', '42', '/images/category/13-12.jpg');
INSERT INTO `dt_category` VALUES ('323', '钙铁锌/维生素', '42', '/images/category/13-13.jpg');
INSERT INTO `dt_category` VALUES ('324', '清火/开胃', '42', '/images/category/13-14.jpg');
INSERT INTO `dt_category` VALUES ('325', '面条/粥', '42', '/images/category/13-15.jpg');
INSERT INTO `dt_category` VALUES ('326', '文学', '43', '/images/category/14-1.jpg');
INSERT INTO `dt_category` VALUES ('327', '童书', '43', '/images/category/14-2.jpg');
INSERT INTO `dt_category` VALUES ('328', '教材教辅', '43', '/images/category/14-3.jpg');
INSERT INTO `dt_category` VALUES ('329', '人文社科', '43', '/images/category/14-4.jpg');
INSERT INTO `dt_category` VALUES ('330', '经管励志', '43', '/images/category/14-5.jpg');
INSERT INTO `dt_category` VALUES ('331', '艺术', '43', '/images/category/14-6.png');
INSERT INTO `dt_category` VALUES ('332', 'IT科技', '43', '/images/category/14-7.jpg');
INSERT INTO `dt_category` VALUES ('333', '文娱', '43', '/images/category/14-8.png');
INSERT INTO `dt_category` VALUES ('334', '教育培训', '43', '/images/category/14-9.jpg');
INSERT INTO `dt_category` VALUES ('335', '生活', '43', '/images/category/14-10.png');
INSERT INTO `dt_category` VALUES ('336', '电子书', '43', '/images/category/14-11.jpg');
INSERT INTO `dt_category` VALUES ('337', '知识服务', '43', '/images/category/14-12.jpg');
INSERT INTO `dt_category` VALUES ('338', '小说', '44', '/images/category/14-13.jpg');
INSERT INTO `dt_category` VALUES ('339', '文学', '44', '/images/category/14-14.png');
INSERT INTO `dt_category` VALUES ('340', '散文随笔', '44', '/images/category/14-15.jpg');
INSERT INTO `dt_category` VALUES ('341', '悬疑/推理', '44', '/images/category/14-16.jpg');
INSERT INTO `dt_category` VALUES ('342', '世界名著', '44', '/images/category/14-17.jpg');
INSERT INTO `dt_category` VALUES ('343', '青春动漫', '44', '/images/category/14-18.jpg');
INSERT INTO `dt_category` VALUES ('344', '跑步鞋', '45', '/images/category/15-1.jpg');
INSERT INTO `dt_category` VALUES ('345', '体育用品', '45', '/images/category/15-2.jpg');
INSERT INTO `dt_category` VALUES ('346', '鱼竿鱼线', '45', '/images/category/15-3.jpg');
INSERT INTO `dt_category` VALUES ('347', '山地车', '45', '/images/category/15-4.jpg');
INSERT INTO `dt_category` VALUES ('348', '篮球鞋', '45', '/images/category/15-5.jpg');
INSERT INTO `dt_category` VALUES ('349', '跑步机', '45', '/images/category/15-6.jpg');
INSERT INTO `dt_category` VALUES ('350', '足球鞋', '45', '/images/category/15-7.jpg');
INSERT INTO `dt_category` VALUES ('351', '冲锋衣裤', '45', '/images/category/15-8.jpg');
INSERT INTO `dt_category` VALUES ('352', '仰卧板/收腹机', '46', '/images/category/15-9.jpg');
INSERT INTO `dt_category` VALUES ('353', '哑铃', '46', '/images/category/15-10.jpg');
INSERT INTO `dt_category` VALUES ('354', '其他机械', '46', '/images/category/15-11.jpg');
INSERT INTO `dt_category` VALUES ('355', '运动护具', '46', '/images/category/15-12.jpg');
INSERT INTO `dt_category` VALUES ('356', '瑜伽用品', '46', '/images/category/15-13.jpg');
INSERT INTO `dt_category` VALUES ('357', '甩脂机', '46', '/images/category/15-14.jpg');
INSERT INTO `dt_category` VALUES ('358', '武术搏击', '46', '/images/category/15-15.jpg');
INSERT INTO `dt_category` VALUES ('359', '跑步机', '46', '/images/category/15-16.jpg');
INSERT INTO `dt_category` VALUES ('360', '动感单车', '46', '/images/category/15-17.jpg');
INSERT INTO `dt_category` VALUES ('361', '综合训练器', '46', '/images/category/15-18.jpg');
INSERT INTO `dt_category` VALUES ('362', '椭圆 机', '46', '/images/category/15-19.jpg');
INSERT INTO `dt_category` VALUES ('363', '踏步机', '46', '/images/category/15-20.jpg');
INSERT INTO `dt_category` VALUES ('364', '内衣馆', '47', '/images/category/16-1.jpg');
INSERT INTO `dt_category` VALUES ('365', '大牌文胸', '47', '/images/category/16-2.jpg');
INSERT INTO `dt_category` VALUES ('366', '自营内衣', '47', '/images/category/16-3.jpg');
INSERT INTO `dt_category` VALUES ('367', '内衣爆款', '47', '/images/category/16-4.jpg');
INSERT INTO `dt_category` VALUES ('368', '女士围巾/披肩', '47', '/images/category/16-5.jpg');
INSERT INTO `dt_category` VALUES ('369', '配饰馆', '47', '/images/category/16-6.jpg');
INSERT INTO `dt_category` VALUES ('370', '男士内裤', '48', '/images/category/16-7.jpg');
INSERT INTO `dt_category` VALUES ('371', '女士内裤', '48', '/images/category/16-8.jpg');
INSERT INTO `dt_category` VALUES ('372', '平角内裤', '48', '/images/category/16-9.jpg');
INSERT INTO `dt_category` VALUES ('373', '蕾丝内裤', '48', '/images/category/16-10.jpg');
INSERT INTO `dt_category` VALUES ('374', '无痕内裤', '48', '/images/category/16-11.jpg');
INSERT INTO `dt_category` VALUES ('375', '低腰内裤', '48', '/images/category/16-12.jpg');
INSERT INTO `dt_category` VALUES ('376', '三角内裤', '48', '/images/category/16-13.jpg');
INSERT INTO `dt_category` VALUES ('377', '中腰内裤', '48', '/images/category/16-14.jpg');
INSERT INTO `dt_category` VALUES ('378', '高腰内裤', '48', '/images/category/16-15.jpg');
INSERT INTO `dt_category` VALUES ('379', '情侣内裤', '48', '/images/category/16-16.jpg');
INSERT INTO `dt_category` VALUES ('380', '棉质内裤', '48', '/images/category/16-17.jpg');
INSERT INTO `dt_category` VALUES ('381', '莫代尔内裤', '48', '/images/category/16-18.jpg');
INSERT INTO `dt_category` VALUES ('400', '小弟弟', '0', '/images/category/1575017126436.png');
INSERT INTO `dt_category` VALUES ('402', '小米长身', '0', null);
INSERT INTO `dt_category` VALUES ('403', '小小小', '402', '/images/category/1575017577616.png');
INSERT INTO `dt_category` VALUES ('404', '小弟弟的哥哥', '400', null);
INSERT INTO `dt_category` VALUES ('406', '小米uu', '0', null);
INSERT INTO `dt_category` VALUES ('407', '小米下的', '406', null);
INSERT INTO `dt_category` VALUES ('408', '小米6', '407', '/images/category/1575875727618.png');

-- ----------------------------
-- Table structure for dt_order
-- ----------------------------
DROP TABLE IF EXISTS `dt_order`;
CREATE TABLE `dt_order` (
  `orderId` varchar(10) NOT NULL,
  `name` varchar(16) NOT NULL,
  `account` int(11) NOT NULL,
  `orderTime` varchar(25) NOT NULL,
  `addressId` int(11) NOT NULL,
  `isPay` int(11) NOT NULL DEFAULT '0',
  `isGoods` int(11) NOT NULL DEFAULT '0' COMMENT '已收货',
  `complete` int(11) NOT NULL DEFAULT '0' COMMENT '完成',
  PRIMARY KEY (`orderId`),
  KEY `fk_order-address_address_id` (`addressId`),
  KEY `fk_order-name-user-name` (`name`),
  CONSTRAINT `fk_order-address_address_id` FOREIGN KEY (`addressId`) REFERENCES `dt_address` (`id`),
  CONSTRAINT `fk_order-name-user-name` FOREIGN KEY (`name`) REFERENCES `dt_user` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dt_order
-- ----------------------------
INSERT INTO `dt_order` VALUES ('MI30148435', 'user1', '399', '2019-11-18 12:49:55.056', '1', '0', '0', '0');
INSERT INTO `dt_order` VALUES ('MI44613989', 'user1', '1995', '2019-12-02 11:02:40.996', '1', '0', '0', '0');
INSERT INTO `dt_order` VALUES ('MI48324339', 'user1', '7361', '2019-12-02 14:32:27.803', '1', '1', '0', '0');
INSERT INTO `dt_order` VALUES ('MI4935832', 'user1', '1597', '2019-11-18 15:20:49.361', '11', '1', '0', '0');
INSERT INTO `dt_order` VALUES ('MI5035131', 'user1', '1198', '2019-11-15 08:39:21.579', '2', '1', '0', '0');
INSERT INTO `dt_order` VALUES ('MI55846730', 'user1', '399', '2019-12-02 14:07:20.864', '11', '1', '0', '0');
INSERT INTO `dt_order` VALUES ('MI56119524', 'user1', '2397', '2019-12-02 11:47:37.650', '2', '1', '0', '0');
INSERT INTO `dt_order` VALUES ('MI73392293', 'user1', '399', '2019-11-15 08:37:34.003', '2', '1', '0', '0');
INSERT INTO `dt_order` VALUES ('MI77784815', 'user1', '1598', '2019-12-02 12:02:53.588', '2', '1', '0', '0');
INSERT INTO `dt_order` VALUES ('MI85914038', 'user1', '1995', '2020-01-01 20:46:31.910', '1', '1', '0', '0');
INSERT INTO `dt_order` VALUES ('MI90358874', 'user1', '3594', '2019-11-15 15:00:18.860', '2', '1', '0', '0');
INSERT INTO `dt_order` VALUES ('MI93828385', 'user1', '1598', '2019-12-02 11:59:24.668', '1', '1', '0', '0');
INSERT INTO `dt_order` VALUES ('MI94016552', 'user1', '798', '2019-12-20 20:55:07.970', '1', '1', '0', '0');
INSERT INTO `dt_order` VALUES ('MI97592507', 'user1', '399', '2019-11-18 17:19:27.555', '1', '1', '0', '0');

-- ----------------------------
-- Table structure for dt_orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `dt_orderdetail`;
CREATE TABLE `dt_orderdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(10) NOT NULL,
  `pid` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dt_orderdetail
-- ----------------------------
INSERT INTO `dt_orderdetail` VALUES ('8', 'MI73392293', '14', '1');
INSERT INTO `dt_orderdetail` VALUES ('9', 'MI5035131', '9', '1');
INSERT INTO `dt_orderdetail` VALUES ('10', 'MI5035131', '14', '1');
INSERT INTO `dt_orderdetail` VALUES ('11', 'MI90358874', '14', '3');
INSERT INTO `dt_orderdetail` VALUES ('12', 'MI90358874', '9', '3');
INSERT INTO `dt_orderdetail` VALUES ('13', 'MI30148435', '14', '1');
INSERT INTO `dt_orderdetail` VALUES ('14', 'MI4935832', '14', '2');
INSERT INTO `dt_orderdetail` VALUES ('15', 'MI4935832', '9', '1');
INSERT INTO `dt_orderdetail` VALUES ('16', 'MI97592507', '14', '1');
INSERT INTO `dt_orderdetail` VALUES ('17', 'MI44613989', '14', '5');
INSERT INTO `dt_orderdetail` VALUES ('18', 'MI56119524', '9', '3');
INSERT INTO `dt_orderdetail` VALUES ('19', 'MI93828385', '9', '2');
INSERT INTO `dt_orderdetail` VALUES ('20', 'MI77784815', '9', '2');
INSERT INTO `dt_orderdetail` VALUES ('21', 'MI55846730', '14', '1');
INSERT INTO `dt_orderdetail` VALUES ('22', 'MI48324339', '14', '1');
INSERT INTO `dt_orderdetail` VALUES ('23', 'MI48324339', '13', '1');
INSERT INTO `dt_orderdetail` VALUES ('24', 'MI48324339', '11', '2');
INSERT INTO `dt_orderdetail` VALUES ('25', 'MI48324339', '1', '2');
INSERT INTO `dt_orderdetail` VALUES ('26', 'MI48324339', '12', '1');
INSERT INTO `dt_orderdetail` VALUES ('27', 'MI94016552', '14', '2');
INSERT INTO `dt_orderdetail` VALUES ('28', 'MI85914038', '14', '5');

-- ----------------------------
-- Table structure for dt_product
-- ----------------------------
DROP TABLE IF EXISTS `dt_product`;
CREATE TABLE `dt_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `fid` int(11) NOT NULL,
  `remark` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '',
  `avatar` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `price` decimal(10,2) NOT NULL,
  `sale` int(11) NOT NULL DEFAULT '0',
  `rate` int(11) NOT NULL DEFAULT '0',
  `banner` varchar(500) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_product_cid_category_id` (`fid`),
  CONSTRAINT `fk_product_cid_category_id` FOREIGN KEY (`fid`) REFERENCES `dt_category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dt_product
-- ----------------------------
INSERT INTO `dt_product` VALUES ('1', '【至高优惠50】vivo Z3 水滴全面屏 高通骁龙处理器 双摄拍照 4G全网通手机 极光蓝 6GB 64GB', '49', '6.3英寸', '/images/list/1-1.jpg', '1098.00', '16160', '84465', '', '1');
INSERT INTO `dt_product` VALUES ('2', '【超级爆品】一加 OnePlus 7T Pro 2K+90Hz流体屏 骁龙855Plus旗舰 4800万超广角 8GB+256GB 海月蓝 游戏手机 ', '49', '6.7英寸', '/images/list/1574870936484.jpg', '4599.00', '45612', '6148', '/images/banner/product/1574861324205.png,/images/banner/product/1574861324528.png,/images/banner/product/1574861324530.png,/images/banner/product/1574866738568.png', '1');
INSERT INTO `dt_product` VALUES ('3', 'Apple iPhone 11 ', '49', '6.1英寸', '/images/list/1-3.jpg ', '5999.00', '46546', '310515', '/images/banner/product/1574862609405.png', '1');
INSERT INTO `dt_product` VALUES ('4', 'ROG 游戏手机2 ', '49', '骁龙855plus ', '/images/list/1-4.jpg ', '3499.00', '4651', '44566', null, '1');
INSERT INTO `dt_product` VALUES ('5', 'vivo iQOO ', '49', '6.41英寸', '/images/list/1-5.jpg ', '2498.00', '1233', '31515', null, '1');
INSERT INTO `dt_product` VALUES ('6', 'vivo iQOO Neo ', '49', '骁龙845(SDM845)', '/images/list/1-6.jpg ', '2298.00', '5615', '15611', null, '1');
INSERT INTO `dt_product` VALUES ('7', 'vivo Z5 ', '49', '6.38英寸', '/images/list/1-7.jpg ', '1598.00', '15615', '15711', null, '1');
INSERT INTO `dt_product` VALUES ('8', 'vivo Z5x ', '49', '6.53英寸', '/images/list/1-8.jpg ', '1398.00', '4564', '35645', null, '1');
INSERT INTO `dt_product` VALUES ('9', 'OPPO A5 ', '49', '超大电池', '/images/list/1-9.jpg ', '799.00', '51612', '262622', null, '1');
INSERT INTO `dt_product` VALUES ('10', 'Apple iPhone 11 Pro Max (A2220) 256GB 暗夜绿色  移动联通电信4G手机 双卡双待 ', '49', '5.8英寸', '/images/list/1-10.jpg ', '9999.00', '16518', '45611', null, '1');
INSERT INTO `dt_product` VALUES ('11', 'vivo U3x ', '49', '双引擎闪充', '/images/list/1-11.jpg ', '999.00', '5615', '10055', null, '1');
INSERT INTO `dt_product` VALUES ('12', 'OPPO K3 ', '49', '升降摄像头', '/images/list/1-12.jpg ', '1799.00', '56115', '315114', null, '1');
INSERT INTO `dt_product` VALUES ('13', '华为（HUAWEI） 荣耀10青春版  {三期白条免息} 原装正品 手机 幻夜黑 4+64G 全网通 ', '49', '6.21英寸', '/images/list/1-13.jpg ', '969.00', '1456', '5611', null, '1');
INSERT INTO `dt_product` VALUES ('14', '多亲（QIN） Qin 1s +AI电话电信VoLTE老人手机双卡双待 移动联通4G 微信直板手机 铁灰色 ', '49', '2.8英寸', '/images/list/1-14.jpg ', '399.00', '615', '1611', 'images/banner/product/14-1.jpg,images/banner/product/14-2.jpg,images/banner/product/14-3.jpg,images/banner/product/14-4.jpg,images/banner/product/14-5.jpg', '1');
INSERT INTO `dt_product` VALUES ('15', '黑鲨 游戏手机2 Pro ', '49', '6.39英寸', '/images/list/1-15.jpg ', '4118.00', '155', '611', null, '1');
INSERT INTO `dt_product` VALUES ('16', '努比亚 nubia 红魔3S电竞游戏手机 8GB+128GB 玄铁黑 骁龙855Plus UFS3.0 内置风扇 5000mAh大电池 全面屏 ', '49', '8GB运存', '/images/list/1-16.jpg ', '2998.00', '5615', '7611', null, '1');
INSERT INTO `dt_product` VALUES ('17', '小米6', '68', '这是一个很牛的手机', '/images/list/1574926086398.png', '2800.00', '0', '0', null, '1');
INSERT INTO `dt_product` VALUES ('18', '小米8', '67', '小米8', '', '1000.00', '0', '0', null, '1');
INSERT INTO `dt_product` VALUES ('19', '小米11', '67', '这是小米11', '', '2000.00', '0', '0', null, '1');
INSERT INTO `dt_product` VALUES ('20', '小米19', '67', '这是小米19', '', '5000.00', '0', '0', null, '1');
INSERT INTO `dt_product` VALUES ('21', '小米25', '67', '小米25', '', '15.00', '0', '0', null, '1');
INSERT INTO `dt_product` VALUES ('22', '小米8', '67', '小米8', '', '159258.00', '0', '0', null, '1');
INSERT INTO `dt_product` VALUES ('23', '小米11', '408', '这是最新款的小米手机 可以试试', '', '14444.00', '0', '0', null, '1');
INSERT INTO `dt_product` VALUES ('24', '小米155', '408', '分包为如果您瑟瑟你发吧跨境电商非你不可绝对是你方便快捷键十多年分不开      ', '/images/list/1575877470490.png', '15555.00', '0', '0', null, '1');

-- ----------------------------
-- Table structure for dt_user
-- ----------------------------
DROP TABLE IF EXISTS `dt_user`;
CREATE TABLE `dt_user` (
  `name` varchar(16) NOT NULL,
  `pwd` varchar(16) NOT NULL,
  `phone` varchar(11) NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `uq_phone` (`phone`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dt_user
-- ----------------------------
INSERT INTO `dt_user` VALUES ('1', '1', '11111111111');
INSERT INTO `dt_user` VALUES ('12', '2', '12222222222');
INSERT INTO `dt_user` VALUES ('123', '123', '12345678974');
INSERT INTO `dt_user` VALUES ('13', '1', '16666666666');
INSERT INTO `dt_user` VALUES ('user1', '123', '17853660885');
INSERT INTO `dt_user` VALUES ('user2', '1', '15365759847');
INSERT INTO `dt_user` VALUES ('user3', '123456', '14756854156');
INSERT INTO `dt_user` VALUES ('小三', '123', '15898574534');
INSERT INTO `dt_user` VALUES ('打算', '123', '15875654220');
INSERT INTO `dt_user` VALUES ('李世镇', '123456', '15865870635');
INSERT INTO `dt_user` VALUES ('清风地下走', '123', '15865875623');
INSERT INTO `dt_user` VALUES ('秋雨不良人', '123', '15865876203');
INSERT INTO `dt_user` VALUES ('笑死', '123456', '17585851443');
INSERT INTO `dt_user` VALUES ('表示的', '123', '15865876253');

-- ----------------------------
-- View structure for order_orderdetail_address_product
-- ----------------------------
DROP VIEW IF EXISTS `order_orderdetail_address_product`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `order_orderdetail_address_product` AS select `t1`.`orderId` AS `orderId`,`t1`.`name` AS `name`,`t1`.`account` AS `account`,`t1`.`orderTime` AS `orderTime`,`t1`.`addressId` AS `addressId`,`t1`.`isPay` AS `isPay`,`t1`.`isGoods` AS `isGoods`,`t1`.`complete` AS `complete`,`t2`.`receiveName` AS `receiveName`,`t2`.`receivePhone` AS `receivePhone`,`t2`.`receiveRegion` AS `receiveRegion`,`t2`.`receiveDetail` AS `receiveDetail`,`t3`.`id` AS `orderdetailId`,`t3`.`count` AS `count`,`t3`.`pid` AS `pid`,`t4`.`name` AS `productName`,`t4`.`remark` AS `remark`,`t4`.`avatar` AS `avatar`,`t4`.`price` AS `price`,`t4`.`status` AS `status` from ((((select `dt_order`.`orderId` AS `orderId`,`dt_order`.`name` AS `name`,`dt_order`.`account` AS `account`,`dt_order`.`orderTime` AS `orderTime`,`dt_order`.`addressId` AS `addressId`,`dt_order`.`isPay` AS `isPay`,`dt_order`.`isGoods` AS `isGoods`,`dt_order`.`complete` AS `complete` from `dt_order`) `t1` join (select `dt_address`.`id` AS `id`,`dt_address`.`name` AS `name`,`dt_address`.`receiveName` AS `receiveName`,`dt_address`.`receivePhone` AS `receivePhone`,`dt_address`.`receiveRegion` AS `receiveRegion`,`dt_address`.`receiveDetail` AS `receiveDetail`,`dt_address`.`isDefault` AS `isDefault` from `dt_address`) `t2` on((`t1`.`addressId` = `t2`.`id`))) join (select `dt_orderdetail`.`id` AS `id`,`dt_orderdetail`.`orderid` AS `orderid`,`dt_orderdetail`.`pid` AS `pid`,`dt_orderdetail`.`count` AS `count` from `dt_orderdetail`) `t3` on((`t1`.`orderId` = `t3`.`orderid`))) join (select `dt_product`.`id` AS `id`,`dt_product`.`name` AS `name`,`dt_product`.`fid` AS `fid`,`dt_product`.`remark` AS `remark`,`dt_product`.`avatar` AS `avatar`,`dt_product`.`price` AS `price`,`dt_product`.`sale` AS `sale`,`dt_product`.`rate` AS `rate`,`dt_product`.`banner` AS `banner`,`dt_product`.`status` AS `status` from `dt_product`) `t4` on((`t3`.`pid` = `t4`.`id`))) ;

-- ----------------------------
-- View structure for product_category
-- ----------------------------
DROP VIEW IF EXISTS `product_category`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `product_category` AS select `t1`.`id` AS `id`,`t1`.`name` AS `name`,`t1`.`fid` AS `fid`,`t1`.`remark` AS `remark`,`t1`.`avatar` AS `avatar`,`t1`.`price` AS `price`,`t1`.`sale` AS `sale`,`t1`.`rate` AS `rate`,`t1`.`banner` AS `banner`,`t1`.`status` AS `status`,`t2`.`name` AS `categoryName`,`t3`.`id` AS `subCategoryId`,`t3`.`name` AS `subCategoryName`,`t4`.`id` AS `mainCategoryId`,`t4`.`name` AS `mainCategoryName` from ((((select `dt_product`.`id` AS `id`,`dt_product`.`name` AS `name`,`dt_product`.`fid` AS `fid`,`dt_product`.`remark` AS `remark`,`dt_product`.`avatar` AS `avatar`,`dt_product`.`price` AS `price`,`dt_product`.`sale` AS `sale`,`dt_product`.`rate` AS `rate`,`dt_product`.`banner` AS `banner`,`dt_product`.`status` AS `status` from `dt_product`) `t1` join (select `dt_category`.`id` AS `id`,`dt_category`.`name` AS `name`,`dt_category`.`fid` AS `fid`,`dt_category`.`avatar` AS `avatar` from `dt_category`) `t2` on((`t1`.`fid` = `t2`.`id`))) join (select `dt_category`.`id` AS `id`,`dt_category`.`name` AS `name`,`dt_category`.`fid` AS `fid`,`dt_category`.`avatar` AS `avatar` from `dt_category`) `t3` on((`t2`.`fid` = `t3`.`id`))) join (select `dt_category`.`id` AS `id`,`dt_category`.`name` AS `name`,`dt_category`.`fid` AS `fid`,`dt_category`.`avatar` AS `avatar` from `dt_category`) `t4` on((`t3`.`fid` = `t4`.`id`))) ;

-- ----------------------------
-- Procedure structure for p_addCategory
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_addCategory`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `p_addCategory`(
	_fid INT,
	_name VARCHAR(20),
  _avatar VARCHAR(100)
)
BEGIN
  INSERT `dt_category`(`fid`, `name`, `avatar`) 
	VALUES(_fid,_name, _avatar);
	SELECT @@IDENTITY AS result;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_addProduct
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_addProduct`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `p_addProduct`(
	_fid INT,
	_name VARCHAR(20),
  _remark VARCHAR(100),
	_price INT
)
BEGIN
  INSERT `dt_product`(`fid`, `name`, `remark`, `price`) VALUES (_fid,_name,_remark,_price);
	SELECT * FROM `product_category` WHERE `id` = @@IDENTITY;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_addProductToCart
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_addProductToCart`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `p_addProductToCart`(
	_name varchar(20),
	_pid int,
	_count int,
	_addTime varchar(30)
)
BEGIN
  DECLARE _curCount INT DEFAULT NULL;
	SELECT `count` INTO _curCount FROM `dt_cart` WHERE `pid` = _pid AND `name` = _name;
	IF _curCount IS NULL THEN	-- 如果没有在购物车中存在
		IF _count > 5 THEN
			SELECT '单个商品购买上限为5个' AS 'result';
		ELSE 
			INSERT `dt_cart`(`name`,`pid`,`count`,`addTime`) 
			VALUES(_name, _pid, _count, _addTime);
			SELECT '' AS 'result';
		END IF;
	ELSE 											-- 如果已经在购物车中存在
		IF _curCount + _count > 5 THEN
			SELECT '单个商品购买上限为5个' AS 'result';
		ELSE
			UPDATE `dt_cart` SET `count` = `count` + _count,`addTime` = _addTime
			WHERE `pid` = _pid AND `name` = _name;
			SELECT '' AS 'result';
		END IF;
	END IF;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_changePwd
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_changePwd`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `p_changePwd`(
	uName varchar(20),
	oldPwd varchar(20),
	newPwd varchar(20)
)
BEGIN
	DECLARE result varchar(20) DEFAULT '原始密码错误';
	DECLARE temp int;

	SELECT count(*) INTO temp FROM dt_admin WHERE `name` = uName AND `pwd` = oldPwd;
	IF temp != 0 THEN
		UPDATE dt_admin SET `pwd` = newPwd WHERE `name` = uName;
		SET result = '';
	END IF;
	SELECT result as result;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_getProductByCondition
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_getProductByCondition`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `p_getProductByCondition`(
	_name VARCHAR(20),  -- 用户输入的查询名字
	_mId INT,						-- 一级分类id
	_sId INT,						-- 二级分类id
	_cId INT,						-- 三级分类id
  _begin INT,         -- 要查看的数据开始的编号
  _count INT          -- 要查看几条数据
)
BEGIN
	-- 获取按当前条件查询(忽略分页)得到的总记录数
	SELECT COUNT(*) AS total FROM `product_category` WHERE 
	`name` LIKE concat('%',_name,'%') AND 
	(_mId = 0 OR (`mainCategoryId` = _mId AND (_sId = 0 OR(`subCategoryId` = _sId AND (_cId = 0 OR `fid` = _cId)))));
	
	-- 获取按当前条件查询，分页情况下应当返回的记录
	SELECT * FROM `product_category` WHERE 
	`name` LIKE concat('%',_name,'%') AND 
	(_mId = 0 OR (`mainCategoryId` = _mId AND (_sId = 0 OR(`subCategoryId` = _sId AND (_cId = 0 OR `fid` = _cId)))))
	LIMIT _begin,_count;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_orderConfirm
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_orderConfirm`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `p_orderConfirm`(
	_ids varchar(50),						-- 要结算的购物记录id
	_account int,								-- 结算的总金额
	_orderTime varchar(30),	  -- 订单产生时间
	_name varchar(20),					-- 用户名
	_addressId int              -- 订单地址id
)
BEGIN
	DECLARE _pid INT;
	DECLARE _count INT;
	DECLARE _id varchar(10) DEFAULT '';
	-- 0. 生成一个随机的有效的课单编号id
	DECLARE _orderId varchar(10);
  SET _orderId = CONCAT('MI', CONVERT(FLOOR(RAND() * 100000000),CHAR));
	-- 1. 向dt_order表插入数据
	INSERT `dt_order`(`orderId`,`name`,`account`,`orderTime`,`addressId`) 
	VALUES (_orderId,_name,_account,_orderTime,_addressId);
	-- 2. 向dt_orderDetail表插入数据
  -- 3. 删除dt_cart表的相关数据
	SET _id = substring_index(_ids, ',', 1);
	WHILE LENGTH(_id) > 0 DO
			SELECT `pid`,`count` INTO _pid,_count FROM `dt_cart` WHERE `id` = CONVERT(_id, SIGNED);
			INSERT `dt_orderDetail`(`orderId`,`pid`,`count`) VALUES (_orderId,_pid,_count);

			DELETE FROM `dt_cart` WHERE `id` = CONVERT(_id, SIGNED);
			SET _ids = substring(_ids, length(_id) + 2);
			SET _id = substring_index(_ids, ',', 1);
	END WHILE;
	SELECT _orderId as 'orderId';
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_removeCategory
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_removeCategory`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `p_removeCategory`(
	_id INT
)
BEGIN
	DECLARE temp INT DEFAULT 0;
	DECLARE result varchar(50) DEFAULT '';

	SELECT COUNT(*) INTO temp FROM `dt_product` WHERE `fid` = _id;
	IF temp > 0 THEN
		SET result = '有商品与当前要删除的分类相关，无法删除..';
	ELSE
		DELETE FROM `dt_category` WHERE `id` = _id;
	END IF;

	SELECT result;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_setDefaultAddress
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_setDefaultAddress`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `p_setDefaultAddress`(
	_id int,					-- 默认地址id
	_name varchar(20) -- 用户名
)
BEGIN
	UPDATE `dt_address` SET `isDefault` = 0 WHERE `name` = _name;
	UPDATE `dt_address` SET `isDefault` = 1 WHERE `id` = _id;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_updateProduct
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_updateProduct`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `p_updateProduct`(
	_cid INT,
	_name VARCHAR(20),
  _remark VARCHAR(100),
	_price INT,
	_id INT
)
BEGIN
  update `dt_product` set `fid`=_cid,`name`=_name,`remark`=_remark,`price`=_price where `id`=_id;
	SELECT * FROM `product_category` WHERE `id` = _id;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_uploadProductAvatar
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_uploadProductAvatar`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `p_uploadProductAvatar`(
	_filePath varchar(100),
	_id int
)
BEGIN
  declare _avatar varchar(100);
	select `avatar` into _avatar from `dt_product` where `id` = _id;
	update `dt_product` set `avatar` = _filePath where `id` = _id;
	select _avatar as 'avatar';
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for p_uploadProductBanner
-- ----------------------------
DROP PROCEDURE IF EXISTS `p_uploadProductBanner`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `p_uploadProductBanner`(
	_filePath VARCHAR(10000),
	_id INT
)
BEGIN
	DECLARE _temp VARCHAR(10000) DEFAULT NULL;
	START TRANSACTION;
	SELECT `banner` INTO _temp FROM `dt_product` WHERE `id` = _id FOR UPDATE;
	IF _temp IS NULL THEN
		UPDATE `dt_product` SET `banner` = _filePath WHERE `id` = _id;
	ELSE
		UPDATE `dt_product` SET `banner` = CONCAT(`banner`, ',', _filePath) 
		WHERE `id` = _id;
	END IF;
	COMMIT;
END
;;
DELIMITER ;
