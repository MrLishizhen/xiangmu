<template>
    <div class="page-wrapper">
        <div class="header">
            <a href="/pages/cart/index.html"></a>
            <h1>确认订单</h1>
        </div>
        <div class="content">
            <div class='price-wra'>
                需支付:
                <span class='price'>
						{{account}}<em>.00</em>
					</span>
            </div>
            <div class='jd-payment'>
                <h2></h2>

                <ul class='list'>
                    <li>
                        <img src="./jd1.png" alt="">
                        <div class='list-title'>
                            <p>使用新卡支付</p>
                            <p>无需网银，免手续费</p>
                            <span>立减6元</span>
                        </div>
                        <i class='checkbox checked'></i>
                    </li>
                    <li>
                        <img src="./yz.png" alt="">
                        <div class='list-title'>
                            <p>使用新卡支付</p>
                            <p>无需网银，免手续费</p>
                            <span>立减6元</span>
                        </div>
                        <i class='checkbox'></i>
                    </li>
                </ul>




            </div>

            <div class='jd-payment-qita'>
                <h2>
                    其他支付方式
                </h2>

                <ul class='list'>
                    <li>
                        <span class='img'></span>
                        <div class='list-title'>
                            <p>微信支付</p>
                            <p>仅安装微信6.0.2 及以上版本客户端使用</p>
                        </div>
                        <i class='checkbox'></i>
                    </li>

                </ul>




            </div>

        </div>
        <footer>
            <button @click="pay">支付￥<span class='price' v-text="account"></span></button>
        </footer>
    </div>

</template>

<script>
    export default {
        name: "index",
        data(){
            return{
                account:0,
                orderId:'',
            }
        },
        methods:{
            pay(){
                this.$http({
                    url: `/order/okaccount/${this.orderId}`
                }).then(() => {
                    this.$toast('付款成功,即将返回首页！');
                })
                setTimeout(()=>{
                    this.$router.replace('/Home');
                },500)
            }
        },
        created() {
             this.orderId= this.$route.query.id


            this.$http({
                url: `/order/account/${this.orderId}`
            }).then(account => {
                this.account=account
            })

        }
    }
</script>

<style scoped>
    .page-wrapper {
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
    }

    .header {
        height: 44px;
        flex-shrink: 0;
        position: relative;
        background: linear-gradient(180deg, #fff, #efefef);
    }

    .header>a {
        position: absolute;
        left: 0;
        top: 0;
        width: 44px;
        height: 100%;

    }

    .header>a::after {
        content: '';
        position: absolute;
        width: 12px;
        height: 12px;
        border-top: 1px solid #848689;
        border-left: 1px solid #848689;
        -webkit-transform-origin: 50%;
        transform-origin: 50%;
        -webkit-transform: rotate(-45deg);
        transform: rotate(-45deg);
        position: absolute;
        top: 50%;
        left: 18px;
        margin-top: -6px;

    }

    .header>h1 {
        text-align: center;
        font-size: 16px;
        font-weight: 500;
        line-height: 44px;
    }

    .content {
        flex-grow: 1;

    }

    .content>.price-wra {
        height: 42px;
        text-align: right;
        line-height: 42px;
        padding: 0 10px;


    }

    .content>.price-wra>span.price {
        color: #f23030;
        font-size: 16px;
    }

    .content>.price-wra>span.price>em {
        font-style: normal;
        font-size: 12px;
    }

    .content>.jd-payment {
        box-shadow: 0 0 0 0 rgba(0, 0, 0, .05), 0 14px 20px 0 rgba(0, 0, 0, .03);
    }

    .content>.jd-payment>h2 {
        background-color: #FFF;
        height: 36px;
        line-height: 33px;
        padding: 11px 0 2px;
        background-image: url(zf.png);
        background-repeat: no-repeat;
        background-size: 131px 30px;
        background-position: center left;
        box-shadow: 0 0 0 0 rgba(0, 0, 0, .05), 0 14px 20px 0 rgba(0, 0, 0, .03);
    }

    .content>.jd-payment {
        padding: 10px;
    }

    .content>.jd-payment>.list {
        box-shadow: 0 0 0 0 rgba(0, 0, 0, .05), 0 14px 20px 0 rgba(0, 0, 0, .03);
    }

    .content>.jd-payment>.list>li {
        display: flex;
        height: 65px;
        margin-left: 10px;
        position: relative;
    }

    .content>.jd-payment>.list>li>img {
        width: 23px;
        height: 23px;
        margin: 18px 18px 3px 5px;
        flex-shrink: 0;
    }

    .content>.jd-payment>.list>li>.list-title {
        display: flex;
        flex-direction: column;
        justify-content: center;

    }

    .content>.jd-payment>.list>li>.list-title>p {
        line-height: 32px;

    }

    .content>.jd-payment>.list>li>.list-title>p:first-child {
        font-size: 14px;
        color: #2E2D2D;
        margin-top: 14px;
        line-height: 15px;
    }

    .content>.jd-payment>.list>li>.list-title>p:nth-child(2) {
        color: #848484;
        font-size: 12px;
    }

    .content>.jd-payment>.list>li>.list-title>span {

        border: 1px solid #f55959;
        border-radius: 26px;
        line-height: 16px;
        padding: 0 6px;
        margin-top: -4px;
        position: absolute;
        right: 50px;
        top: 50%;
        background: #FFF;
        height: 14px;
        margin-left: 9px;
        color: #f55959;
        font-size: 9px;
    }

    .content>.jd-payment>.list>li>i,
    .content>.jd-payment-qita>.list>li>i {
        width: 24px;
        height: 24px;
        position: absolute;
        top: 50%;
        right: 21px;
        margin-top: -7px;
        background-color: red;
        border-radius: 50%;
        background: url(./checkbox.png) no-repeat center center/100%;
    }

    .content>.jd-payment>.list>li>i.checked,
    .content>.jd-payment-qita>.list>li>i.checked {
        background: url(./checked.png) no-repeat center center/100%;
    }

    .jd-payment-qita>h2 {
        padding: 15px 13px;
        font-size: 15px;
        color: #848689;
        margin-top: 10px;
    }

    .jd-payment-qita>.list {
        padding: 0 10px;
    }

    .jd-payment-qita>.list>li {
        display: flex;
        align-items: center;
        height: 65px;
        position: relative;
        box-shadow: 0 2px 15px 0 rgba(0, 0, 0, .05), 0 14px 20px 0 rgba(0, 0, 0, .03);
    }

    .jd-payment-qita>.list>li>span {
        background-image: url(zfs.png);
        background-repeat: no-repeat;
        background-position: 0 -93px;
        background-size: 100%;
        width: 23px;
        height: 23px;
        margin: 18px 18px 3px 5px;
    }

    footer {
        height: 50px;
    }

    footer>button {
        width: 100%;
        height: 100%;
        background: linear-gradient(to right, #F02F0F, #F95C22);
        font-size: 15px;
        line-height: 50px;
        color:#fff;
    }

</style>