import http from '../util/http'
//突然发现这个地方用不着，在详情页本页就可以做的事情

export default{//这里请求的是当前用户的购物记录

    namespaced:true,
    state:{

    },
    getters:{

    },
    mutations:{

    },
    actions:{

    },
}