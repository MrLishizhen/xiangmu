<!--统筹安排页面中所有的组件-->

<template>
	<!--页面的模板-->

	<router-view></router-view>

	<!--路由要渲染的组件的占位符，这个是vue-router的组件-->

</template>

<script type="text/ecmascript-6">
//	组件的相关js代码
//	导出组件
	export default {

	}
</script>

<style scoped>
	/*尽量不要用标签名来做选择器*/
	/*组件相关的HTML的样式*/
</style>